var frameModule = require("ui/frame");
var HomeViewModel = require("./home-view-model");

var homeViewModel = new HomeViewModel();

function pageLoaded(args) {
  
  var page = args.object;

  page.bindingContext = homeViewModel;
}

function onItemTap(args) { 
  page.frame.navigate({
    myBackBut: "Meals"
  });
}

exports.pageLoaded = pageLoaded;
