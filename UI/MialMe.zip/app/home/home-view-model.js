var observableModule = require("data/observable");

function HomeViewModel() {
  var viewModel = observableModule.fromObject({
    textFieldValue: "",

    onButtonTap: function () {
      console.log("Button was pressed");
    },

    album: {
        bandName: "Ed Sheeran",
        albumName: "X",
        year: "2017",
        owned: true,
        myRating: "9.5"
    },

      
  });

  return viewModel;
}

module.exports = HomeViewModel;
