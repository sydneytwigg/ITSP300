var observableModule = require("data/observable");

function MealsViewModel() {
    var viewModel = observableModule.fromObject({

    });

    return viewModel;
}

module.exports = MealsViewModel;
