var frameModule = require("ui/frame");
var MealsViewModel= require("./meals-view-model");

var MealsViewModel = new mealsViewModel();

function pageLoaded(args) {

    var page = args.object;

    page.bindingContext = mealsViewModel;
}
exports.pageLoaded = pageLoaded;