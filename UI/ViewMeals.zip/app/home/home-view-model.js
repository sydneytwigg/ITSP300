var observableModule = require("data/observable");

function HomeViewModel() {
  var viewModel = observableModule.fromObject({
      
  });

  return viewModel;
}

module.exports = HomeViewModel;
