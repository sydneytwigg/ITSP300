var createViewModel = require("./home-items-view-model").createViewModel;
var Sqlite = require("nativescript-sqlite");

function onNavigatingTo(args) {
  var page = args.object;
  if (!Sqlite.exists("eatforlife.db")) {
    Sqlite.copyDatabase("eatforlife.db");
  }

  var db_name = "eatforlife.db";

    new Sqlite(db_name).then(db => {
        page.bindingContext = createViewModel(db);
    });

}

exports.onNavigatingTo = onNavigatingTo;
