const observableModule = require("tns-core-modules/data/observable");
var dialogs = require("tns-core-modules/ui/dialogs");
var Sqlite = require("nativescript-sqlite");

function createViewModel(db) {
    var viewModel = Observable();

    viewModel.firstname = "";
    viewModel.lastname = "";

    	viewModel.select = function(){
		db.all("SELECT * FROM client").then(rows => {
			for(var row in rows){
				dialogs.alert({
   		 title: "Your title",
   		 message: "Your message",
   		 okButtonText: "Your button text"
		}).then(function () {
  		  console.log("Dialog closed!");
		});
				
			}
		}, error =>{
			console.log("SELECT ERROR",error);
		});
    	}

    return viewModel;
}

exports.createViewModel = createViewModel;

