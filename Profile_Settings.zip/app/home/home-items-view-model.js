const observableModule = require("data/observable");

function HomeItemsViewModel() {
    const viewModel = observableModule.fromObject({
        items: [
            {
                name: "View Profile"
            },
            {
                name: "Change Password"
            },
            {
                name: "BMI Details"
            },
            {
                name: "Graphs"
            },
            {
                name: "Goals"
            }
        ]
    });

    return viewModel;
}

module.exports = HomeItemsViewModel;
